#include "class.h"
#include <iostream>
using namespace std;
int Add(int a, int b)
{
	return a + b;
}

SavingAccount::SavingAccount(int date, int id, double rate) :id(id), balance(0), rate(rate), lastDate(date), accumulation(0) {
	cout << "#" << id << "is created" << endl;
}
double SavingAccount::accumulate(double date) {
	return accumulation + balance * (date - lastDate);
}
void SavingAccount::record(int date, double amount) {
	accumulation = accumulate(date);
	lastDate = date;
	amount = round(amount * 100) / 100.00;
	balance += amount;
	cout << date << "\t#" << id << "\t" << amount << "\t" << balance << endl;
}
void SavingAccount::deposit(int date, double amount) {
	record(date, amount);
}
void SavingAccount::withdrawl(int date, double amount) {
	if (amount > balance)
		cout << "not enough money" << endl;
	else
		record(date, -amount);
}
void SavingAccount::show() {
	cout << "#" << id << "\tBalance" << balance << endl;
}
void SavingAccount::settle(int date) {
	double interest = accumulate(date) * rate / 365;
	if (interest != 0)
		record(date, interest);
	accumulation = 0;
}


int max(int a, int b)
{
	if (a > b) return(a); else return (b);
}

int min(int a, int b)
{
	if (a > b) return(b); else return (a);
}

Date::Date()
{
	month = day = year = 1;
}

/*Date::Date(int mn, int dy, int yr)
{
	static int length[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	month = max(1, mn);
	month = min(month, 12);

	day = max(1, dy);
	day = min(day, length[month]);

	year = max(1, yr);
}*/
/*void Date::setDate()
{
	int tempdate;
	cin >> tempdate;
	Date(tempdate);
}*/

Date::Date(int longdate)
{
	static int length[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	int yr = longdate / 10000;
	int mn = longdate / 100 % 100;
	int dy = longdate % 100;

	month = max(1, mn);
	month = min(month, 12);

	day = max(1, dy);
	day = min(day, length[month]);

	year = max(1, yr);
}

void Date::display()
{
	cout << '\n' << day << ' ' << month << "," << year << '\n';

	cout << '\n' << year;
	if (month / 10 == 0)
		cout << "0" << month;
	else cout << month;
	if (day / 10 == 0)
		cout << "0" << day;
	else cout << day;
}

Date::~Date()
{
}

int Date::GetMonth()
{
	return month;
}

void Date::SetMonth(int mn)
{
	month = max(1, mn);
	month = min(month, 12);
}