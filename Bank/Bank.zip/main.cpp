
#include <iostream>
#include<cmath>
#include"class.h"
using namespace std;

int main()
{
	SavingAccount s1(0, 11111, 0.015);
	s1.deposit(5, 5000);
	s1.deposit(45, 5500);
	s1.settle(90);
	s1.show();
	/*Date setdate();
	Date mydate(20010831);
	mydate.display();
	system("pause");*/
	return 0;
}
